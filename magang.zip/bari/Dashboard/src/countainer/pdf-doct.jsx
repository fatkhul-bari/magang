import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';
import { useEffect, useState } from 'react';

const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 10,
  },
  title: {
    fontSize: 14,
    marginBottom: 10,
    textAlign: 'center',
  },
  row: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#000',
    paddingVertical: 4,
  },
  cell: {
    width: '20%',
    textAlign: 'left',
  },
});

function MyDoct() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch('http://localhost/bari/Dashboard/backend/api/get-tb.php')
      .then(res => res.json())
      .then(data => setUsers(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <Document>
      <Page style={styles.page}>
        <Text style={styles.title}>Data Catatan Harian</Text>

        {/* Header */}
        <View style={styles.row}>
          <Text style={styles.cell}>No</Text>
          <Text style={styles.cell}>Nama</Text>
          <Text style={styles.cell}>Aktivitas</Text>
          <Text style={styles.cell}>Kompetensi</Text>
          <Text style={styles.cell}>Dibuat</Text>
        </View>

        {/* Body */}
        {users.length === 0 ? (
          <Text>Data kosong</Text>
        ) : (
          users.map((user, index) => (
            <View style={styles.row} key={user.id}>
              <Text style={styles.cell}>{index + 1}</Text>
              <Text style={styles.cell}>{user.username}</Text>
              <Text style={styles.cell}>{user.activity}</Text>
              <Text style={styles.cell}>{user.competence}</Text>
              <Text style={styles.cell}>{user.create_at}</Text>
            </View>
          ))
        )}
      </Page>
    </Document>
  );
}

export default MyDoct;
