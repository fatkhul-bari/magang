import shiroko from '../assets/profil.jpg'
import './sidebar.css'

function Profil() {
    return (
        <div className="profil">
            <img src={shiroko}/>
        </div>
    )
}

function Name() {
    return (
        <h1 className='name'>A. Fatkhul Bari</h1>
    )
}

function List() {
    return (
        <div className="list">
            <a href="#"><i class="fa-solid fa-coins"></i> Data</a>
            <a href="#" onClick={logout}><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
        </div>
    )
}

function logout() {
  if (window.confirm("Are You Sure?")) {
    window.location = "http://localhost/bari/form%20login/";
  }
}

function Footer() {
    return (
        <div className="footer">
        <p>2026 | A. Fatkhul Bari</p>
        </div>
    )
}

function Sidebar() {
    return (
        <>
            <div className="sidebar">
                {Profil()}
                {Name()}
                {List()}
                {Footer()}
            </div>
        </>
    )
}

export default Sidebar