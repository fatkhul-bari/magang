import React, { useState, useEffect } from 'react';
import './main.css'
import { PDFDownloadLink } from '@react-pdf/renderer';
import MyDoct from './pdf-doct.jsx';

function Header() {
    return (
        <div className="header">
            <div className="rubix"></div>
            <h1>Dashboard</h1>
        </div>
    )
}

function Data() {
    const [users, setUsers] = useState([]);

    useEffect(() => {

    fetch('http://localhost/bari/Dashboard/backend/api/get-tb.php')
       .then(res => res.json())
       .then(data => {
           setUsers(data);
        })
    }, []);  
    
function dropData(id) {
    if (confirm("Are Youre Sure?")) {
        fetch(`http://localhost/bari/Dashboard/backend/api/delete.php?id=${id}`)
            .then(res => res.text())
            .then(response => {
                setUsers(prevUsers =>
                    prevUsers.filter(user => user.id !== id)
                );
                alert(response);
            })
            .catch(err => {
                alert(err);
            })
    }
}

function InsertData() {
    const usernameInput = document.getElementById('usernameInput')
    const activityInput = document.getElementById('activityInput')
    const categorySelect = document.getElementById('categoryInput')

    fetch(`http://localhost/bari/Dashboard/backend/api/create.php?username=${usernameInput.value}&activity=${activityInput.value}&competence=${categorySelect.value}`)
        .then(res => res.text())
        .then(response => {
            location.reload();
        })
        .catch(err => {
            alert(err);
        })
}

function DownloadButton() {
  return (
    <PDFDownloadLink document={<MyDoct />} fileName="data.pdf" style={{ textDecoration: 'none' }}>
      {({ loading }) =>
        loading ? 'Menyiapkan PDF...' : 'Download PDF'
      }
    </PDFDownloadLink>
  );
}

    return (
        <div className='tabel-data'>
            <h2>Data</h2>

            <table cellPadding="8" cellSpacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Aktivitas</th>
                        <th>Kompetensi</th>
                        <th>Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    {users.length === 0 ? (
                        <tr>
                            <td colSpan="2" align="center">Data kosong</td>
                        </tr>
                    ) : (
                        users.map((user, index) => (
                            <tr key={user.id}>
                                <td>{index + 1}</td>
                                <td>{user.username}</td>
                                <td>{user.activity}</td>
                                <td>{user.competence}</td>
                                <td>{user.create_at}</td>
                                <td>
                                    <button onClick={() => {dropData(user.id)}}>Hapus</button>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
                <tfoot>
                    <tr>
                        <td>Tambah</td>
                        <td>
                            <input type="text" placeholder='Username' id='usernameInput'/>
                        </td>
                        <td>
                            <input type="text" placeholder='Activity' id='activityInput' />
                        </td>
                        <td colSpan="2">
                            <select id="categoryInput">
                                <option value="PWPB">PWPB</option>
                                <option value="DPPLG">DPPLG</option>
                                <option value="DB">DB</option>
                            </select>
                        </td>
                        <td>
                            <button onClick={() => {InsertData()}}>Tambah</button>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <div className="pdf">
                <DownloadButton />
            </div>
        </div>
    );
}


function Main() {
    return (
        <>
            <div className="main">
                <Header />
                <Data />
            </div>
        </>
    )
}

export default Main