import React, { useEffect, useState } from 'react';
import './App.css'
import sidebar from './countainer/sidebar.jsx'
import main from './countainer/main.jsx'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div className="countainer">
        {sidebar()}
        {main()}
      </div>
    </>
  )
}

export default App