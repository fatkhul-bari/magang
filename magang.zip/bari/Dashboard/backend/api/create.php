<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include "../connect/koneksi.php";

    $username = $_GET['username'];
    $activity = $_GET['activity'];
    $competence = $_GET['competence'];

    $query = "INSERT INTO tb_activity (username, activity, competence) VALUES ('$username', '$activity', '$competence')";
    mysqli_query($conn, $query);

    if ($query) {
        echo "data telah ditambahkan!";
    } else {
        echo "gagal menambahkan data!";
    }
?>