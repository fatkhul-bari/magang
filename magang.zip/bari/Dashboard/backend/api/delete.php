<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include "../connect/koneksi.php";

try {
    $id = $_GET['id'];
    $query = "DELETE FROM tb_activity WHERE id=$id";
    mysqli_query($conn, $query);

    echo "Data berhasil dihapus";
} catch (\Throwable $th) {
    echo "Kesalahan :" . $th;
}

?>