<?php 

$hostname = "localhost";
$username = "root";
$password = "";
$database = "db_dashboard";

$conn = mysqli_connect($hostname, $username, $password, $database);

if (!$conn) {
    die("GAGAL!" . mysqli_connect_error());
}

?>