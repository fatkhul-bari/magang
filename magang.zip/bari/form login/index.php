<?php
require_once("koneksi.php");

    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $query = mysqli_query($conn, "SELECT * FROM tb_admin WHERE username='$username' AND password='$password'");
    
    if (mysqli_num_rows($query) > 0) {
        header("Location: http://localhost:5174/");
        exit;
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/form-login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
</head>
<body>
    <form action="" method="POST">
        <h1>Login</h1>

        <input type="text" placeholder="username" name="username" required>
        <input type="password" placeholder="password" name="password" id="password" required>

        <button type="submit" class="btn" name="submit">Login</button>
    </form>
    <script src="js/form-login.js"></script>    
</body>
</html>